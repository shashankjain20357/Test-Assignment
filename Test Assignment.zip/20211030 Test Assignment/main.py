import os
import pandas as pd
from bs4 import BeautifulSoup
import requests
import re
from nltk.tokenize import sent_tokenize, word_tokenize

# import nltk
# nltk.download('punkt')

# Read the input Excel file
input_file = "Input.xlsx"
df = pd.read_excel(input_file)
print(df)

# Define a function to extract article text from a URL
def extract_article_text(url):
    try:
        # Send an HTTP GET request to the URL
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception if there's an HTTP error
        
        # Parse the HTML content of the page using BeautifulSoup
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Extract the article title and text
        title = soup.find('h1').text  
        
        article_text = ''
        article_content = soup.find('div', class_='td-post-content')
    
        # Iterate through paragraphs and concatenate them
        for paragraph in article_content.find_all('p'):
            article_text += paragraph.get_text() + '\n'

        return title, article_text
    
    except Exception as e:
        print(f"Error while extracting from {url}: {str(e)}")
        return None, None


def save_article(df): 
    # Loop through the DataFrame and extract article text
    for index , row in df.iterrows():
        url_id = row['URL_ID']
        url = row['URL']
        
        title, article_text = extract_article_text(url)
        
        if title and article_text:
            # Save the extracted article to a text file
            filename = f"articles\{url_id}.txt"
            with open(filename, 'w', encoding='utf-8') as file:
                file.write(f"Title: {title}\n\n")
                file.write(article_text)
            print(f"Saved article from {url} to {filename}")

# function to save the article in text file call only onces to avoid the duplication during analysis
#save_article(df)

# the folder where text files are stored
article_folder = "articles" 

#the folder where stop word files are stored
stopword_folder = "StopWords" 

# Initialize an empty set to store stop words
stop_words = set()

# Loop through each file in the folder
for filename in os.listdir(stopword_folder):
    if filename.endswith(".txt"):
        with open(os.path.join(stopword_folder, filename), "r") as stopword_file:
            # Read and split the stop words from the current file and add them to the set
            stop_words.update(stopword_file.read().splitlines())


# Load positive words from the text file
with open("MasterDictionary\\positive-words.txt", "r") as positive_words_file:
    positive_words = set(positive_words_file.read().splitlines())

# Load negative words from the text file
with open("MasterDictionary\\negative-words.txt", "r") as negative_words_file:
    negative_words = set(negative_words_file.read().splitlines())


# print("stopword" , len(stop_words))
# print("positiveword" , len(positive_words))
# print("negativeword" , len(negative_words))


# Function to calculate the number of syllables in a word
def syllable_count(word):
    word = word.lower()
    if len(word) <= 3:
        return 1
    count = 0
    vowels = "aeiouy"
    if word[0] in vowels:
        count += 1
    for i in range(1, len(word)):
        if word[i] in vowels and word[i - 1] not in vowels:
            count += 1
    if word.endswith("e"):
        count -= 1
    if word.endswith("le"):
        count += 1
    if count == 0:
        count = 1
    return count



# Function to perform text analysis on an article
def analyze_text(article_text):
    # Remove punctuation and convert to lowercase
    article_text = re.sub(r'[^\w\s]', '', article_text).lower()

    # Tokenize the text into words
    words = word_tokenize(article_text)

    # Remove custom stopwords
    words = [word for word in words if word not in stop_words]

    # Calculate word count
    word_count = len(words)

    # Calculate complex word count (words with more than two syllables)
    complex_word_count = sum(1 for word in words if syllable_count(word) > 2)

    # Calculate syllable per word
    syllables = sum(syllable_count(word) for word in words)
    syllable_per_word = syllables / word_count

    # Calculate average sentence length
    sentences = sent_tokenize(article_text)
    avg_sentence_length = word_count / len(sentences)

    # Calculate percentage of complex words
    percentage_complex_words = (complex_word_count / word_count) * 100

    # Calculate Fog Index
    fog_index = 0.4 * (avg_sentence_length + percentage_complex_words)

    # Calculate sentiment scores

    # Initialize positive and negative scores
    positive_score = 0
    negative_score = 0
    # Calculate sentiment scores
    for word in words:
        if word in positive_words:
            positive_score += 1
        elif word in negative_words:
            negative_score += 1

    # Multiply the negative score by -1
    negative_score *= -1

    # Calculate polarity score
    polarity_score = (positive_score - negative_score) / ((positive_score + negative_score) + 0.000001)

    # Calculate subjectivity score
    subjectivity_score = (positive_score + negative_score) / (word_count + 0.000001)

    # Calculate personal pronouns count
    personal_pronouns = len(re.findall(r'\b(I|we|my|ours|us)\b', article_text, flags=re.IGNORECASE))

    # Calculate average word length
    avg_word_length = sum(len(word) for word in words) / word_count

    return {
        'POSITIVE SCORE': positive_score,
        'NEGATIVE SCORE': negative_score,
        'POLARITY SCORE': polarity_score,
        'SUBJECTIVITY SCORE': subjectivity_score,
        'AVG SENTENCE LENGTH': avg_sentence_length,
        'PERCENTAGE OF COMPLEX WORDS': percentage_complex_words,
        'FOG INDEX': fog_index,
        'AVG NUMBER OF WORDS PER SENTENCE': avg_sentence_length,
        'COMPLEX WORD COUNT': complex_word_count,
        'WORD COUNT': word_count,
        'SYLLABLE PER WORD': syllable_per_word,
        'PERSONAL PRONOUNS': personal_pronouns,
        'AVG WORD LENGTH': avg_word_length

    }


# output data structure file
results_df = pd.read_excel('Output Data Structure.xlsx')

# print(results_df)
# print(results_df.isnull().sum())

analysis_results=[]

# Loop through each text file    
for index , row in results_df.iterrows(): 
    url_id = row['URL_ID']
    url = row['URL']
    
    filename = f"articles/{url_id}.txt"
    
    if os.path.exists(filename):       
        with open(filename, 'r', encoding='utf-8') as file:
            article_text = file.read()

            # Analyze the article 
            analysis_result = analyze_text(article_text)

        # Add the URL_ID and URL to the analysis result
        analysis_result['URL_ID'] = url_id
        analysis_result['URL'] = url

        # Append the analysis result to the DataFrame
        analysis_results.append(analysis_result)


# Convert the list of analysis results to a DataFrame
analysis_results_df = pd.DataFrame(analysis_results)

# Reorder columns to match the desired order
desired_column_order = [
    'URL_ID',
    'URL',
    'POSITIVE SCORE',
    'NEGATIVE SCORE',
    'POLARITY SCORE',
    'SUBJECTIVITY SCORE',
    'AVG SENTENCE LENGTH',
    'PERCENTAGE OF COMPLEX WORDS',
    'FOG INDEX',
    'AVG NUMBER OF WORDS PER SENTENCE',
    'COMPLEX WORD COUNT',
    'WORD COUNT',
    'SYLLABLE PER WORD',
    'PERSONAL PRONOUNS',
    'AVG WORD LENGTH'
]

analysis_results_df = analysis_results_df[desired_column_order]

# Save the analysis results to the output Excel file
analysis_results_df.to_excel('Output Data Structure.xlsx', index=False)

#print(analysis_results_df.describe())
